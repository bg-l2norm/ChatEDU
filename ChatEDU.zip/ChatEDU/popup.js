// Initialize click counter
let clickCount = 0;

